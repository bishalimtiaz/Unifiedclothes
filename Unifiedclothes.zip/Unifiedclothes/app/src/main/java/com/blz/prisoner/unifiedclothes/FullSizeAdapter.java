package com.blz.prisoner.unifiedclothes;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class FullSizeAdapter extends PagerAdapter implements
        ActivityCompat.OnRequestPermissionsResultCallback {

    private Context context;
    private List<Images> imagesList;
    //private ImageView imageView;

    private Images images;

    private LayoutInflater inflater;
    private static final int PERMISSION_REQUEST_CODE = 1;


    public FullSizeAdapter(Context context, List<Images> imagesList) {
        this.context = context;
        this.imagesList = imagesList;
    }

    @Override
    public int getCount() {
        return imagesList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }


    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {

        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View v = inflater.inflate(R.layout.full_screen_item_layout,null);

        final ImageView imageView = v.findViewById(R.id.img);

        ImageButton ebay_button = v.findViewById(R.id.ebay_button);
        ImageButton amazon_button = v.findViewById(R.id.amazon_button);
        ImageButton share_button = v.findViewById(R.id.share_button);
        ImageButton download_button = v.findViewById(R.id.download_button);

        ebay_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,Integer.toString(position),Toast.LENGTH_SHORT).show();
            }
        });

        amazon_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,Integer.toString(position),Toast.LENGTH_SHORT).show();
            }
        });

        share_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,Integer.toString(position),Toast.LENGTH_SHORT).show();
            }
        });

        download_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){


                    if (checkPermission())
                    {
                        // Code for above or equal 23 API Oriented Device
                        // Your Permission granted already .Do next code
                        FileOutputStream ouputStream=null;
                        BitmapDrawable drawable = (BitmapDrawable) imageView.getDrawable();
                        Bitmap bitmap = drawable.getBitmap();
                        File filepath = Environment.getExternalStorageDirectory()

                        //Toast.makeText(context,Integer.toString(position),Toast.LENGTH_SHORT).show();



                    } else {

                        requestPermission(); // Code for permission
                    }

                }

                else{
                    Toast.makeText(context,"Permission Is Granted..",Toast.LENGTH_SHORT).show();

                }
            }
        });



        images = imagesList.get(position);

        Glide.with(context).load(images.getImagePath()).apply(new RequestOptions().centerInside()).into(imageView);

        ViewPager vp = (ViewPager) container;
        vp.addView(v,0);
        return v;



    }

    //end of instantiateItem

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {

        ViewPager viewPager = (ViewPager) container;

        View view = (View) object;
        viewPager.removeView(view);
    }


    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(context, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void requestPermission() {

        ActivityCompat.requestPermissions((Activity) context, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(context,"Permission Granted, Now you can use local drive .",Toast.LENGTH_LONG).show();
                } else {

                    Toast.makeText(context,"Permission Denied, You Should Allow External Storage Permission To Download Images.",Toast.LENGTH_LONG).show();
                }
                break;
        }
    }


}
