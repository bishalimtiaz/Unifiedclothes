package com.blz.prisoner.unifiedclothes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

public class FullScreenActivity extends Activity {


    private ViewPager viewPager;
    private List<Images> imagesList;

    //Images images;


    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_screen);

        if(savedInstanceState==null){
            Intent intent = getIntent();
            Bundle extras = intent.getExtras();
            imagesList = (List<Images>) extras.getSerializable("IMAGES");
            position = extras.getInt("POSITION",0);
        }
        viewPager = findViewById(R.id.viewPager);
        //images = imagesList.get(position);
        //Toast.makeText(FullScreenActivity.this,images.getImagePath(),Toast.LENGTH_SHORT).show();


        FullSizeAdapter fullSizeAdapter = new FullSizeAdapter(FullScreenActivity.this,imagesList);
        viewPager.setAdapter(fullSizeAdapter);
        viewPager.setCurrentItem(position);

    }
}
